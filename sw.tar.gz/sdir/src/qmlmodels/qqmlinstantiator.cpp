// Copyright (C) 2016 Research In Motion.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant

#include "qqmlinstantiator_p.h"
#include "qqmlinstantiator_p_p.h"
#include <QtQml/QQmlContext>
#include <QtQml/QQmlComponent>
#include <QtQml/QQmlInfo>
#include <QtQml/QQmlError>
#include <QtQmlModels/private/qqmlobjectmodel_p.h>
#if QT_CONFIG(qml_delegate_model)
#include <QtQmlModels/private/qqmldelegatemodel_p.h>
#endif

QT_BEGIN_NAMESPACE

QQmlInstantiatorPrivate::QQmlInstantiatorPrivate()
    : componentComplete(true)
    , effectiveReset(false)
    , active(true)
    , async(false)
#if QT_CONFIG(qml_delegate_model)
    , ownModel(false)
#endif
{
}

void QQmlInstantiatorPrivate::clear()
{
    Q_Q(QQmlInstantiator);
    if (!instanceModel)
        return;

    if (objects.isEmpty())
        return;

    for (int i=0; i < objects.size(); i++) {
        QObject *object = objects[i];
        emit q->objectRemoved(i, object);
        instanceModel->release(object);
        if (object && object->parent() == q)
            object->setParent(nullptr);
    }

    objects.clear();
    emit q->objectChanged();
}

QObject *QQmlInstantiatorPrivate::modelObject(int index, bool async)
{
    requestedIndex = index;
    QObject *o = instanceModel->object(index, async ? QQmlIncubator::Asynchronous : QQmlIncubator::AsynchronousIfNested);
    requestedIndex = -1;
    return o;
}


void QQmlInstantiatorPrivate::regenerate()
{
    Q_Q(QQmlInstantiator);
    if (!componentComplete)
        return;

    int prevCount = q->count();

    clear();

    if (!active || !instanceModel || !instanceModel->count() || !instanceModel->isValid()) {
        if (prevCount)
            q->countChanged();
        return;
    }

    for (int i = 0; i < instanceModel->count(); i++) {
        QObject *object = modelObject(i, async);
        // If the item was already created we won't get a createdItem
        if (object)
            _q_createdItem(i, object);
    }
    if (q->count() != prevCount)
        q->countChanged();
}

void QQmlInstantiatorPrivate::_q_createdItem(int idx, QObject* item)
{
    Q_Q(QQmlInstantiator);
    if (objects.contains(item)) //Case when it was created synchronously in regenerate
        return;
    if (requestedIndex != idx) // Asynchronous creation, reference the object
        (void)instanceModel->object(idx);
    if (!item->parent())
        item->setParent(q);
    if (objects.size() < idx + 1) {
        int modelCount = instanceModel->count();
        if (objects.capacity() < modelCount)
            objects.reserve(modelCount);
        objects.resize(idx + 1);
    }
    if (QObject *o = objects.at(idx))
        instanceModel->release(o);
    objects.replace(idx, item);
    if (objects.size() == 1)
        q->objectChanged();
    q->objectAdded(idx, item);
}

void QQmlInstantiatorPrivate::_q_modelUpdated(const QQmlChangeSet &changeSet, bool reset)
{
    Q_Q(QQmlInstantiator);

    if (!componentComplete || effectiveReset || !active)
        return;

    if (reset) {
        regenerate();
        if (changeSet.difference() != 0)
            q->countChanged();
        return;
    }

    int difference = 0;
    QHash<int, QVector<QPointer<QObject> > > moved;
    const QVector<QQmlChangeSet::Change> &removes = changeSet.removes();
    for (const QQmlChangeSet::Change &remove : removes) {
        int index = qMin(remove.index, objects.size());
        int count = qMin(remove.index + remove.count, objects.size()) - index;
        if (remove.isMove()) {
            moved.insert(remove.moveId, objects.mid(index, count));
            objects.erase(
                    objects.begin() + index,
                    objects.begin() + index + count);
        } else while (count--) {
            QObject *obj = objects.at(index);
            objects.remove(index);
            q->objectRemoved(index, obj);
            if (obj)
                instanceModel->release(obj);
        }

        difference -= remove.count;
    }

    const QVector<QQmlChangeSet::Change> &inserts = changeSet.inserts();
    for (const QQmlChangeSet::Change &insert : inserts) {
        int index = qMin(insert.index, objects.size());
        if (insert.isMove()) {
            QVector<QPointer<QObject> > movedObjects = moved.value(insert.moveId);
            objects = objects.mid(0, index) + movedObjects + objects.mid(index);
        } else {
            if (insert.index <= objects.size())
                objects.insert(insert.index, insert.count, nullptr);
            for (int i = 0; i < insert.count; ++i) {
                int modelIndex = index + i;
                QObject* obj = modelObject(modelIndex, async);
                if (obj)
                    _q_createdItem(modelIndex, obj);
            }
        }
        difference += insert.count;
    }

    if (difference != 0)
        q->countChanged();
}

#if QT_CONFIG(qml_delegate_model)
void QQmlInstantiatorPrivate::makeModel()
{
    Q_Q(QQmlInstantiator);
    QQmlDelegateModel* delegateModel = new QQmlDelegateModel(qmlContext(q), q);
    instanceModel = delegateModel;
    ownModel = true;
    delegateModel->setDelegate(delegate);
    delegateModel->setDelegateModelAccess(delegateModelAccess);
    delegateModel->classBegin(); //Pretend it was made in QML
    if (componentComplete)
        delegateModel->componentComplete();
}
#endif


/*!
    \qmltype Instantiator
    \nativetype QQmlInstantiator
    \inqmlmodule QtQml.Models
    \ingroup qtquick-models
    \brief Dynamically creates objects.

    A Instantiator can be used to control the dynamic creation of objects, or to dynamically
    create multiple objects from a template.

    The Instantiator element will manage the objects it creates. Those objects are parented to the
    Instantiator and can also be deleted by the Instantiator if the Instantiator's properties change. Objects
    can also be destroyed dynamically through other means, and the Instantiator will not recreate
    them unless the properties of the Instantiator change.

    \note Instantiator is part of QtQml.Models since version 2.14 and part of QtQml since
    version 2.1. Importing Instantiator via QtQml is deprecated since Qt 5.14.
*/
QQmlInstantiator::QQmlInstantiator(QObject *parent)
    : QObject(*(new QQmlInstantiatorPrivate), parent)
{
}

QQmlInstantiator::~QQmlInstantiator()
{
    Q_D(QQmlInstantiator);
    d->clear();
}

/*!
    \qmlsignal QtQml.Models::Instantiator::objectAdded(int index, QtObject object)

    This signal is emitted when an object is added to the Instantiator. The \a index
    parameter holds the index which the object has been given, and the \a object
    parameter holds the \l QtObject that has been added.
*/

/*!
    \qmlsignal QtQml.Models::Instantiator::objectRemoved(int index, QtObject object)

    This signal is emitted when an object is removed from the Instantiator. The \a index
    parameter holds the index which the object had been given, and the \a object
    parameter holds the \l QtObject that has been removed.

    Do not keep a reference to \a object if it was created by this Instantiator, as
    in these cases it will be deleted shortly after the signal is handled.
*/
/*!
    \qmlproperty bool QtQml.Models::Instantiator::active

    When active is true, and the delegate component is ready, the Instantiator will
    create objects according to the model. When active is false, no objects
    will be created and any previously created objects will be destroyed.

    Default is true.
*/
bool QQmlInstantiator::isActive() const
{
    Q_D(const QQmlInstantiator);
    return d->active;
}

void QQmlInstantiator::setActive(bool newVal)
{
    Q_D(QQmlInstantiator);
    if (newVal == d->active)
        return;
    d->active = newVal;
    emit activeChanged();
    d->regenerate();
}

/*!
    \qmlproperty bool QtQml.Models::Instantiator::asynchronous

    When asynchronous is true the Instantiator will attempt to create objects
    asynchronously. This means that objects may not be available immediately,
    even if active is set to true.

    You can use the objectAdded signal to respond to items being created.

    Default is false.
*/
bool QQmlInstantiator::isAsync() const
{
    Q_D(const QQmlInstantiator);
    return d->async;
}

void QQmlInstantiator::setAsync(bool newVal)
{
    Q_D(QQmlInstantiator);
    if (newVal == d->async)
        return;
    d->async = newVal;
    emit asynchronousChanged();
}


/*!
    \qmlproperty int QtQml.Models::Instantiator::count

    The number of objects the Instantiator is currently managing.
*/

int QQmlInstantiator::count() const
{
    Q_D(const QQmlInstantiator);
    return d->objects.size();
}

/*!
    \qmlproperty QtQml::Component QtQml.Models::Instantiator::delegate
    \qmldefault

    The component used to create all objects.

    Note that an extra variable, index, will be available inside instances of the
    delegate. This variable refers to the index of the instance inside the Instantiator,
    and can be used to obtain the object through the objectAt method of the Instantiator.

    If this property is changed, all instances using the old delegate will be destroyed
    and new instances will be created using the new delegate.
*/
QQmlComponent* QQmlInstantiator::delegate()
{
    Q_D(QQmlInstantiator);
    return d->delegate;
}

void QQmlInstantiator::setDelegate(QQmlComponent* c)
{
    Q_D(QQmlInstantiator);
    if (c == d->delegate)
        return;

    d->delegate = c;
    emit delegateChanged();

#if QT_CONFIG(qml_delegate_model)
    if (!d->ownModel)
        return;

    if (QQmlDelegateModel *dModel = qobject_cast<QQmlDelegateModel*>(d->instanceModel))
        dModel->setDelegate(c);
    if (d->componentComplete)
        d->regenerate();
#endif
}

/*!
    \qmlproperty variant QtQml.Models::Instantiator::model

    This property can be set to any of the supported \l {qml-data-models}{data models}:

    \list
    \li A number that indicates the number of delegates to be created by the repeater
    \li A model (e.g. a ListModel item, or a QAbstractItemModel subclass)
    \li A string list
    \li An object list
    \endlist

    The type of model affects the properties that are exposed to the \l delegate.

    Default value is 1, which creates a single delegate instance.

    \sa {qml-data-models}{Data Models}
*/

QVariant QQmlInstantiator::model() const
{
    Q_D(const QQmlInstantiator);
#if QT_CONFIG(qml_delegate_model)
    if (!d->ownModel)
        return QVariant::fromValue(d->instanceModel);

    return d->instanceModel
            ? static_cast<QQmlDelegateModel *>(d->instanceModel)->model()
            : QVariant(0);
#else
    return QVariant::fromValue(d->instanceModel);
#endif
}

void QQmlInstantiator::setModel(const QVariant &v)
{
    Q_D(QQmlInstantiator);
    QQmlInstanceModel *prevModel = d->instanceModel;

#if QT_CONFIG(qml_delegate_model)
    if (d->ownModel) {
        if (!prevModel) {
            if (v == QVariant(0))
                return;
        } else if (static_cast<QQmlDelegateModel *>(prevModel)->model() == v) {
            return;
        }
    } else if (QVariant::fromValue(prevModel) == v) {
        return;
    }
#else
    if (QVariant::fromValue(prevModel) == v)
        return;
#endif

    QObject *object = qvariant_cast<QObject*>(v);
    QQmlInstanceModel *vim = nullptr;
    if (object && (vim = qobject_cast<QQmlInstanceModel *>(object))) {
#if QT_CONFIG(qml_delegate_model)
        if (d->ownModel) {
            delete d->instanceModel;
            prevModel = nullptr;
            d->ownModel = false;
        }
#endif
        d->instanceModel = vim;
#if QT_CONFIG(qml_delegate_model)
    } else if (v == QVariant(0) && !d->instanceModel) {
        // Optimization: If the model is initially 0, we don't even create an instance model.
        d->ownModel = true;
    } else {
        if (!d->ownModel || !d->instanceModel)
            d->makeModel();

        if (QQmlDelegateModel *dataModel = qobject_cast<QQmlDelegateModel *>(d->instanceModel)) {
            d->effectiveReset = true;
            dataModel->setModel(v);
            d->effectiveReset = false;
        }
#endif
    }

    if (d->instanceModel != prevModel) {
        if (prevModel) {
            disconnect(prevModel, SIGNAL(modelUpdated(QQmlChangeSet,bool)),
                    this, SLOT(_q_modelUpdated(QQmlChangeSet,bool)));
            disconnect(prevModel, SIGNAL(createdItem(int,QObject*)), this, SLOT(_q_createdItem(int,QObject*)));
            //disconnect(prevModel, SIGNAL(initItem(int,QObject*)), this, SLOT(initItem(int,QObject*)));
            // If it was our own model before, we've deleted it. No need to disconnect anything
        }

        if (d->instanceModel) {
            connect(d->instanceModel, SIGNAL(modelUpdated(QQmlChangeSet,bool)),
                    this, SLOT(_q_modelUpdated(QQmlChangeSet,bool)));
            connect(d->instanceModel, SIGNAL(createdItem(int,QObject*)), this, SLOT(_q_createdItem(int,QObject*)));
            //connect(d->instanceModel, SIGNAL(initItem(int,QObject*)), this, SLOT(initItem(int,QObject*)));

            if (d->ownModel) {
                QObject::connect(
                        static_cast<QQmlDelegateModel *>(d->instanceModel),
                        &QQmlDelegateModel::modelChanged, this, [this, d]() {
                    if (!d->effectiveReset)
                        emit modelChanged();
                });
            }
        }
    }

    d->regenerate();
    emit modelChanged();
}

#if QT_CONFIG(qml_delegate_model)
/*!
    \qmlproperty enumeration QtQml.Models::Instantiator::delegateModelAccess
    \since 6.10

    \include delegatemodelaccess.qdocinc
*/

QQmlDelegateModel::DelegateModelAccess QQmlInstantiator::delegateModelAccess() const
{
    Q_D(const QQmlInstantiator);
    return d->delegateModelAccess;
}

void QQmlInstantiator::setDelegateModelAccess(
        QQmlDelegateModel::DelegateModelAccess delegateModelAccess)
{
    Q_D(QQmlInstantiator);
    if (delegateModelAccess == d->delegateModelAccess)
        return;

    d->delegateModelAccess = delegateModelAccess;
    emit delegateModelAccessChanged();

    if (!d->ownModel)
        return;

    if (QQmlDelegateModel *dModel = qobject_cast<QQmlDelegateModel*>(d->instanceModel))
        dModel->setDelegateModelAccess(delegateModelAccess);
    if (d->componentComplete)
        d->regenerate();
}
#endif

/*!
    \qmlproperty QtObject QtQml.Models::Instantiator::object

    This is a reference to the first created object, intended as a convenience
    for the case where only one object has been created.
*/
QObject *QQmlInstantiator::object() const
{
    Q_D(const QQmlInstantiator);
    if (d->objects.size())
        return d->objects[0];
    return nullptr;
}

/*!
    \qmlmethod QtObject QtQml.Models::Instantiator::objectAt(int index)

    Returns a reference to the object with the given \a index.
*/
QObject *QQmlInstantiator::objectAt(int index) const
{
    Q_D(const QQmlInstantiator);
    if (index >= 0 && index < d->objects.size())
        return d->objects[index];
    return nullptr;
}

/*!
 \internal
*/
void QQmlInstantiator::classBegin()
{
    Q_D(QQmlInstantiator);
    d->componentComplete = false;
}

/*!
 \internal
*/
void QQmlInstantiator::componentComplete()
{
    Q_D(QQmlInstantiator);
    d->componentComplete = true;
#if QT_CONFIG(qml_delegate_model)
    if (!d->ownModel) {
        if (!d->instanceModel)
            setModel(QVariant(1));
        else
            d->regenerate();
        return;
    }

    if (!d->instanceModel)
        return; // It's 0: Nothing to do

    // Disregard any modelUpdated() triggered by componentComplete() and rather regenerate manually.
    // See also setModel().
    d->effectiveReset = true;
    static_cast<QQmlDelegateModel*>(d->instanceModel)->componentComplete();
    d->effectiveReset = false;
#endif

    d->regenerate();
}

QT_END_NAMESPACE

#include "moc_qqmlinstantiator_p.cpp"
